import ProductCard from "../Components/ProductCard";

export default function Products() {
  const products = [
    {
      name: "Wireless Earbuds",
      price: 59,
      image: "https://via.placeholder.com/200",
    },
    { name: "Power Bank", price: 29, image: "https://via.placeholder.com/200" },
    { name: "Smart Lamp", price: 39, image: "https://via.placeholder.com/200" },
    { name: "Mini Fan", price: 19, image: "https://via.placeholder.com/200" },
  ];

  return (
    <div style={{ padding: "20px" }}>
      <h2>Our Products</h2>
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "20px",
          marginTop: "20px",
        }}
      >
        {products.map((p, i) => (
          <ProductCard key={i} {...p} />
        ))}
      </div>
    </div>
  );
}
