import ProductCard from "../Components/ProductCard";

export default function Home() {
  const featured = [
    {
      name: "Smart Watch",
      price: 99,
      image: "https://via.placeholder.com/200",
    },
    {
      name: "Bluetooth Speaker",
      price: 49,
      image: "https://via.placeholder.com/200",
    },
  ];

  return (
    <div style={{ padding: "20px" }}>
      <h2>Welcome to MiniStore</h2>
      <p>Find the best deals on your favorite gadgets!</p>

      <div
        style={{
          display: "flex",
          gap: "20px",
          flexWrap: "wrap",
          marginTop: "20px",
        }}
      >
        {featured.map((item, i) => (
          <ProductCard key={i} {...item} />
        ))}
      </div>
    </div>
  );
}
