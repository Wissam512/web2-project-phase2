import "../Assets/ProductCard.css";
const  ProductCard = ({ name, price, image }) => {
  return (
    <div className="card">
      <img src={image} alt={name} className="card-img" />
      <h3>{name}</h3>
      <p>${price}</p>
      <button className="buy-btn">Add to Cart</button>
    </div>
  );
}


export default ProductCard;