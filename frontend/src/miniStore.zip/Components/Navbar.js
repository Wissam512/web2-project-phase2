import { Link } from "react-router-dom";
import "../Assets/Navbar.css";

export default function Navbar() {
  return (
    <nav className="navbar">
      <h1 className="logo">MiniStore</h1>
      <div className="links">
        <Link to="/">Home</Link>
        <Link to="/products">Products</Link>
        <Link to="/contact">Contact</Link>
      </div>
    </nav>
  );
}
